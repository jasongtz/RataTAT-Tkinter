from modularui import csv_autolog

csv_autolog()